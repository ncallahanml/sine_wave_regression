# sine_wave_regression
Using neural networks to detect properties of noisy sinusoidal inputs
